package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC_001AccountRegistrationTest extends BaseClass {

    // ========== TEST CASE ==========
    @Test
    public void accountVerification() {
        HomePage hp = new HomePage(driver);
        hp.clickMyAccount();
        hp.clickRegister();

        AccountRegistrationPage arp = new AccountRegistrationPage(driver);
        arp.setFirstName(randomString().toUpperCase());
        arp.setLastName(randomString().toUpperCase());
        arp.setEmail(randomString() + "@gmail.com");
        arp.setTelephone(randomNumber());

        String password = randomAlphaNumeric();

        arp.setPassword(password);
        arp.setConfirmPassword(password);

        arp.selectNewsletter();
        arp.checkPrivacyPolicy();
        arp.clickContinue();

        String confirmationMsg = arp.getConfirmationMessage();
        Assert.assertEquals(confirmationMsg, "Your Account Has Been Created!");
    }


}
