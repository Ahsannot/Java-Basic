package testBase;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;

public class BaseClass {
    public WebDriver driver;
    public ChromeOptions options;

    // ========== SETUP ==========
    @BeforeClass
    public void setup() {
        options = new ChromeOptions();                    // initialize
        options.addArguments("--incognito");              // add arguments

        driver = new ChromeDriver(options);

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://tutorialsninja.com/demo/");
        driver.manage().window().maximize();
    }

    // ========== TEARDOWN ==========
    @AfterClass
    public void tearDown() {
        driver.quit();
    }

    // ========== RANDOM DATA HELPERS ==========

    public String randomString() {
        return RandomStringUtils.randomAlphabetic(5); // e.g., "Abcde"

    }

    public String randomNumber() {
        return RandomStringUtils.randomNumeric(10); // e.g., "1234567890"
    }

    public String randomAlphaNumeric() {
        return RandomStringUtils.randomAlphanumeric(8); // e.g., "A1B2C3D4"
    }
}
